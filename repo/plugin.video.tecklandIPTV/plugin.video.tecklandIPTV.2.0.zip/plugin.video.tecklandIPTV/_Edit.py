import xbmcaddon

MainBase = 'https://pastebin.com/raw/T5gh8Xn7'
addon = xbmcaddon.Addon('plugin.video.tecklandIPTV')